package server;
import common.Response;

public interface OurObserver {
    void update(Response asd);
}
