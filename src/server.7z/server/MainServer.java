package server;

public class MainServer {
    public static void main(String[] args) {
        Server newServer = new Server();
        newServer.startServer();
    }
}
